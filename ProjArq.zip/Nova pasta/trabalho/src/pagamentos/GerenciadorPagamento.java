package pagamentos;

// Singleton
class GerenciadorPagamento {
    private static GerenciadorPagamento instancia;

    private GerenciadorPagamento() {}

    public static GerenciadorPagamento getInstance() {
        if (instancia == null) {
            instancia = new GerenciadorPagamento();
        }
        return instancia;
    }

    public void processarPagamento(String metodo, double valor) {
        System.out.println("Processando pagamento de R$" + valor + " via " + metodo);
    }
}
