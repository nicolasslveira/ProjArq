package pagamentos;

// Decorator - Classe Base
class PagamentoBase implements Pagamento {
    @Override
    public void pagar(double valor) {
        System.out.println("Pagamento de R$" + valor + " realizado.");
    }
}
