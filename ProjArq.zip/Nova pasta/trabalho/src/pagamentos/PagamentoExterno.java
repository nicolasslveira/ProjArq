package pagamentos;

// Adapter
interface PagamentoExterno {
    void realizarPagamento(double valor);
}
