package pagamentos;

public class Main {
    public static void main(String[] args) {
        // Singleton
        GerenciadorPagamento gerenciador = GerenciadorPagamento.getInstance();
        gerenciador.processarPagamento("Cartão de Crédito", 200.0);

        // Adapter
        PagamentoExterno pagamentoPayPal = new PayPalAdapter();
        pagamentoPayPal.realizarPagamento(150.0);

        // Decorator
        Pagamento pagamento = new PagamentoBase();
        Pagamento pagamentoComDesconto = new PagamentoComDesconto(pagamento, 10);
        pagamentoComDesconto.pagar(100.0);
    }
}
