package pagamentos;

// Decorator
interface Pagamento {
    void pagar(double valor);
}
