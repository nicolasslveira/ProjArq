package pagamentos;

// Adapter - Serviço Externo
class PayPalService {
    public void pagarViaPayPal(double valor) {
        System.out.println("Pagamento de R$" + valor + " realizado via PayPal");
    }
}
