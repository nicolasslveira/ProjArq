package pagamentos;

// Adapter - Implementação
class PayPalAdapter implements PagamentoExterno {
    private PayPalService payPalService;

    public PayPalAdapter() {
        this.payPalService = new PayPalService();
    }

    @Override
    public void realizarPagamento(double valor) {
        payPalService.pagarViaPayPal(valor);
    }
}
