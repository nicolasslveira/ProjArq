package pagamentos;

// Decorator - Implementação
class PagamentoComDesconto implements Pagamento {
    private Pagamento pagamento;
    private double desconto;

    public PagamentoComDesconto(Pagamento pagamento, double desconto) {
        this.pagamento = pagamento;
        this.desconto = desconto;
    }

    @Override
    public void pagar(double valor) {
        double valorComDesconto = valor - (valor * desconto / 100);
        pagamento.pagar(valorComDesconto);
        System.out.println("Desconto de " + desconto + "% aplicado!");
    }
}
